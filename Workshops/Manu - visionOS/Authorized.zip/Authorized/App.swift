import SwiftUI
import CoreLocation

@main
struct AuthorizedApp: App {
    var body: some Scene {
        @StateObject var locationManager = LocationManager()

        WindowGroup {
            Text("Authorized Bug")
                .onAppear {
                    Task {
                        let authorization = await locationManager.requestAuthorization()

                        switch authorization {
                        case .notDetermined, .restricted, .denied:
                            print("failed")
                        case .authorizedAlways, .authorizedWhenInUse:
                            print("getLocation")
            // When Apple Vision Pro Simulator is the platform to deploy, IF THIS #if around is removed, an error appears in Xcode 16 Beta 5 but disappears directly after.
            #if !os(visionOS)
                        case .authorized:
                            print("getLocation")
            #endif
                        default:
                            print("default / failed")
                        }
                    }
                }
        }
    }
}

// From CLLocationManager.h (which I don't quite understand the meaning of...)

// #if defined(TARGET_OS_VISION) && TARGET_OS_VISION
//     kCLAuthorizationStatusAuthorized API_DEPRECATED("Use kCLAuthorizationStatusAuthorizedAlways", ios(2.0, 8.0)) API_AVAILABLE(macos(10.6)) API_UNAVAILABLE(watchos, tvos, visionos) = kCLAuthorizationStatusAuthorizedAlways
// #else
//     kCLAuthorizationStatusAuthorized API_DEPRECATED("Use kCLAuthorizationStatusAuthorizedAlways", ios(2.0, 8.0)) API_AVAILABLE(macos(10.6)) API_UNAVAILABLE(watchos, tvos) = kCLAuthorizationStatusAuthorizedAlways
// #endif
// };
 

final class LocationManager: NSObject, ObservableObject {
    @Published var currentAuthorizationStatus: CLAuthorizationStatus?
    
    private let coreLocationManager: CLLocationManager
    private var requestAuthorizationContinuation: CheckedContinuation<CLAuthorizationStatus, Never>?
    
    init(coreLocationManager: CLLocationManager = CLLocationManager()) {
        self.coreLocationManager = coreLocationManager
        super.init()
        currentAuthorizationStatus = coreLocationManager.authorizationStatus
    }
    
    /// Requests the user’s permission to use location services while the app is in use.
    /// - Returns: Constants indicating the app's authorization to use location services.
    func requestAuthorization() async -> CLAuthorizationStatus {
        let status = await withCheckedContinuation { continuation in
            requestAuthorizationContinuation = continuation
            coreLocationManager.requestWhenInUseAuthorization()
        }
        requestAuthorizationContinuation = nil
        return status
    }
}

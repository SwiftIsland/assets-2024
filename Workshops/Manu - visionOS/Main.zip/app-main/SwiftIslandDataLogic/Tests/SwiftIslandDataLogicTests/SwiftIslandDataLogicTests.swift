import XCTest
@testable import SwiftIslandDataLogic

final class SwiftIslandDataLogicTests: XCTestCase {
    func testExample() throws {
    }
}

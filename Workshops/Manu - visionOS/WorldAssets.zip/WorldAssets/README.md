# WorldAssets

This package contains some model assets that Hello World uses, including:
 * A globe.
 * An Earth with moving clouds and ground light that turns off when the sun
   is overhead.
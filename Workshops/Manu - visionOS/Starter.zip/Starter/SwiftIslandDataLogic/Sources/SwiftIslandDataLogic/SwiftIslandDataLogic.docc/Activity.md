# Activity

A workshop conference consist of just that, activities.

## Overview

A workshop conference consist of just that, activities. Most of them, and of course most importantly these are workshops... but there are many more types 
of activities. An Activity is something a participant can join. This can be a workshop or an action such as a social activity like a bicycle ride or a 
board game in the evening, or it can be a mandatory activity such as checking in or participating at the opening to the conference. 
An activity can contain mentors or it can be without any.

## Topics

### See also

- ``ActivityType``

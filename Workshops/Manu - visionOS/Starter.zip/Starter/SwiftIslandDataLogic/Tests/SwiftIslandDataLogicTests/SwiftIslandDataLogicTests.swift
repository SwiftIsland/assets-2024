import XCTest
#if os(visionOS)
@testable import SwiftIslandLocalDataLogic
#else
@testable import SwiftIslandDataLogic
#endif

final class SwiftIslandDataLogicTests: XCTestCase {
    func testExample() throws {
    }
}

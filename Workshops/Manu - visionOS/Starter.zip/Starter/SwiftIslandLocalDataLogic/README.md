# SwiftIsland Local DataLogic

The local / no internet / hard coded version of the SwiftIsland Firebase Store.
